export { default } from './TranslatedText'
