export { default as Input } from './Input'
export type { InputProps, Scales as InputScales } from './types'
