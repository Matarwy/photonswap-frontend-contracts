export { default as Tag } from './Tag'
export type { TagProps, Variants as TagVariants } from './types'
