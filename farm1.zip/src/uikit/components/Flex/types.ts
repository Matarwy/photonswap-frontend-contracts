import { FlexboxProps, SpaceProps } from 'styled-system'

export interface FlexProps extends FlexboxProps, SpaceProps {}
