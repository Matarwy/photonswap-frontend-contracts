export type OverlayProps = {
  show: boolean
  zIndex?: number
}
